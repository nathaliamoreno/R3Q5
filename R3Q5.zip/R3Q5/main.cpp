#include <iostream>
#include "Funcionario.h"
#include "Horista.h"
#include "Assalariado.h"
#include "SistemaGerenciaFolha.h"
#include "Comissionado.h"

using namespace std;


int main()
{
    cout << "\n\t**** SISTEMA DE GERENCIAMENTO DE FOLHA ****" << endl;

 //   Funcionario f[100];
    Assalariado f[100];

    int j;
    double salarioBase = 1000;

    f[0].setNome("REBECA");
    f[0].setMatricula(123);

    f[1].setNome("NATHALIA");
    f[1].setMatricula(456);

    cout << "testando calcula salario\n";

    cout << f[0].getNome() << endl;
    cout << f[0].getMatricula() << endl;
    cout << f[0].calcularSalario(salarioBase);


    return 0;
}

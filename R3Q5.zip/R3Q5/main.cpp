#include <iostream>
#include "Funcionario.h"
#include "Horista.h"
#include "Assalariado.h"
#include "SistemaGerenciaFolha.h"
#include "Comissionado.h"

using namespace std;

#define salarioBase 1000.0

int main()
{
    cout << "\n\t**** SISTEMA DE GERENCIAMENTO DE FOLHA ****" << endl;

    Assalariado f_assalariado;
    Comissionado f_comissionado = Comissionado(2000, 10);   //passando vendas semanais e percentual da comissao;
    Horista f_horista = Horista(45); //passando horas totais trabalhadas na semana

    int j;


    f_assalariado.setNome("REBECA");
    f_assalariado.setMatricula(123);

    f_comissionado.setNome("NATHALIA");
    f_comissionado.setMatricula(456);

    f_horista.setNome("DERZU");
    f_horista.setMatricula(789);

    cout << "\n\n SALARIO BASE PARA TODOS: R$ 1000\n\n" << endl;

    cout << "\n\n<<<< testando assalariado >>>>\n";

    cout << "\n Nome: " << f_assalariado.getNome() << endl;
    cout << "\n Matricula: " << f_assalariado.getMatricula() << endl;
    cout << "\n Salario: R$ " << f_assalariado.calcularSalario(salarioBase)<< endl;;

    cout << "\n\n<<<< testando comissionado >>>>\n";

    cout << "\n Nome: " << f_comissionado.getNome() << endl;
    cout << "\n Matricula: " << f_comissionado.getMatricula() << endl;
    cout << "\n Comissao definida em 10% em cima de R$ 2000\n\n Salario: R$ " << f_comissionado.calcularSalario(salarioBase)<<endl;

    cout << "\n\n<<<< testando horista >>>>\n";

    cout << "\n Nome: " << f_horista.getNome() << endl;
    cout << "\n Matricula: " << f_horista.getMatricula() << endl;
    cout << "\n Horas trabalhadas definidas como 45h \n\n Salario: R$ " << f_horista.calcularSalario(salarioBase)<< endl;;


    return 0;
}

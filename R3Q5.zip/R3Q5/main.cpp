#include <iostream>

using namespace std;

SalarioBase = 1000;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}

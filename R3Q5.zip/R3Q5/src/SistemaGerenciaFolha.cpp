#include "SistemaGerenciaFolha.h"
#include "Funcionario.h"

#include <iostream>
#include <string>

SistemaGerenciaFolha::SistemaGerenciaFolha()
{

}
void SistemaGerenciaFolha::setFuncionarios(Funcionario func , int i)
{

    funcionarios[i] = func;

    i++;
}

double SistemaGerenciaFolha::calculaValorTotalFolha(int j)
{

    double valorTotal = 0.0;

    for(int i = 0; i < j; i++){
        valorTotal += funcionarios[i].calcularSalario();
    }

    return valorTotal;
}
double SistemaGerenciaFolha::consultaSalarioFuncionario(int j)
{
    std::string n, n2;
    double s;

    std::cout << "Digite o Nome: ";
    std::cin >> n;

   for(int i = 0; i < j; i++){
       n2 = funcionarios[i].getNome();
        if(n == n2){
            s = funcionarios[i].calcularSalario();
        }
    }

    return s;
}

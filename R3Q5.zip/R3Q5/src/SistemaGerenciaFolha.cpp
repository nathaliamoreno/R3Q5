#include "SistemaGerenciaFolha.h"

SistemaGerenciaFolha::SistemaGerenciaFolha()
{
}
void SistemaGerenciaFolha::setFuncionarios()
{

}
double SistemaGerenciaFolha::calculaValorTotalFolha()
{

}
double SistemaGerenciaFolha::consultaSalarioFuncionario()
{

}

#include "Funcionario.h"

Funcionario::Funcionario(std::string n, int mat)
{
    nome = n;
    matricula = mat;
}
double Funcionario::calcularSalario()
{
}
void setNome(std::string n)
{
    nome = n;
}
void setMatricula(int mat)
{
    matricula = mat;
}
std::string getNome()
{
    return nome;
}
int getMatricula()
{
    return matricula;
}

#include "Horista.h"

Horista::Horista()
{
}

double Horista::calcularSalario(double salarioBase, double H_trabalhadas)
{
    double salario;

    horasTrabalhadas = H_trabalhadas - 40;
    salarioPorHora = salarioBase/40;

    salario = salarioBase + (horasTrabalhadas*(salarioPorHora*1.5));

    return salario;

}

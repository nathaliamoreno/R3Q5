#include "Horista.h"

Horista::Horista(double H_trabalhadas)
{
    horasTrabalhadas = H_trabalhadas;
}
double Horista::calcularSalario(double salarioBase)
{
    double salario =0;

    horasTrabalhadas = horasTrabalhadas - 40;
    salarioPorHora = salarioBase/40;

    salario = salarioBase + (horasTrabalhadas*(salarioPorHora*1.5));

    return salario;

}

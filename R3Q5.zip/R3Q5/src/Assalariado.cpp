#include "Assalariado.h"

#include "Funcionario.h"
#include <iostream>

Assalariado::Assalariado()
{
}
double Assalariado::calcularSalario(double salarioBase){

        salario = salarioBase;

        return salario;
}

#include "Assalariado.h"

#include "Funcionario.h"
#include <iostream>

Assalariado::Assalariado()
{
    //salario = 0.0;
}
double Assalariado::calcularSalario(double salarioFixo){
        return salario;
}

#include "Assalariado.h"

Assalariado::Assalariado()
{
}
double Assalariado::calcularSalario(double salarioFixo){
        return salario;
}

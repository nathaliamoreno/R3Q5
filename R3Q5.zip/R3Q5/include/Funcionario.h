#ifndef FUNCIONARIO_H
#define FUNCIONARIO_H
#include <iostream>
#include <string>


class Funcionario
{
    public:
        Funcionario(std::string n, int mat);
        virtual double calcularSalario();
        void setNome(std::string n);
        void setMatricula(int mat);
        std::string getNome();
        int getMatricula();

    private:
        std::string nome;
        int matricula;


};

#endif // FUNCIONARIO_H

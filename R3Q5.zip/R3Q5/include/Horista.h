#ifndef HORISTA_H
#define HORISTA_H


class Horista : public Funcionario
{
    public:
        Horista();
        double calcularSalario(double salarioBase, double H_trabalhadas);

        double salarioPorHora;
        double horasTrabalhadas;

    protected:

    private:
};

#endif // HORISTA_H

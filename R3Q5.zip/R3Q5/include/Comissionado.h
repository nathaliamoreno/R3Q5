#ifndef COMISSIONADO_H
#define COMISSIONADO_H


class Comissionado : public Funcionario
{
    public:
        Comissionado(double V_Semanais, double percent_Comissao);
        double calcularSalario();

        double vendasSemanais;
        double percentualComissao;

    protected:

    private:
};

#endif // COMISSIONADO_H

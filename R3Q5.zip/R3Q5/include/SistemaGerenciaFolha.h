#ifndef SISTEMAGERENCIAFOLHA_H
#define SISTEMAGERENCIAFOLHA_H
#include "Funcionario.h"


class SistemaGerenciaFolha
{
    public:
        SistemaGerenciaFolha();
        void setFuncionarios(Funcionario func , int i);
        double calculaValorTotalFolha(int j);
        double consultaSalarioFuncionario(int j);

        Funcionario funcionarios[100];

    protected:

    private:
};

#endif // SISTEMAGERENCIAFOLHA_H

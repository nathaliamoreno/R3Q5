#ifndef ASSALARIADO_H
#define ASSALARIADO_H

#include "Funcionario.h"


class Assalariado : public Funcionario
{
    public:
        Assalariado();
        double calcularSalario(double salarioFixo);

        double salario;

    protected:

    private:
};

#endif // ASSALARIADO_H

#ifndef ASSALARIADO_H
#define ASSALARIADO_H


class Assalariado : public Funcionario
{
    public:
        Assalariado();
        double calcularSalario(double salarioFixo);

        double salario;

    protected:

    private:
};

#endif // ASSALARIADO_H

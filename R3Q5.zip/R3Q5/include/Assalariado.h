#ifndef ASSALARIADO_H
#define ASSALARIADO_H

#include "Funcionario.h"


class Assalariado : public Funcionario
{
    public:
        Assalariado();
        double calcularSalario(double salarioBase);



    protected:

    private:
        double salario;
};

#endif // ASSALARIADO_H
